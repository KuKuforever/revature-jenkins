CREATE TRIGGER AFTERDELETETRIGGER
AFTER DELETE
  ON EMPLOYEE
FOR EACH ROW
  DECLARE 
    uName VARCHAR2(128);
BEGIN
    SELECT USER INTO uName FROM DUAL;
    DBMS_OUTPUT.PUT_LINE(uName || ' performed delete on tbale EMPLOYEE, Employee with ID '
    ||:OLD.employeeId||' is deleted');
END;
/
