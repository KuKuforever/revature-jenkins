CREATE TRIGGER AFTERARTISTINSERT
AFTER INSERT
  ON ARTIST
FOR EACH ROW
  BEGIN
    DBMS_OUTPUT.PUT_LINE('There are now '||artistCount.currval || 'artist in the database');
END;
/
