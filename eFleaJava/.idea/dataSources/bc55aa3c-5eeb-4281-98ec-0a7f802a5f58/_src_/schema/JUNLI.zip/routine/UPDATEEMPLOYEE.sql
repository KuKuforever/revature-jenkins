CREATE PROCEDURE updateEmployee
(idIn IN NUMBER, 
lnameIn IN VARCHAR2, 
fnameIn IN VARCHAR2, 
titleIn IN VARCHAR2,
reportstoIn IN NUMBER,
birthdateIn IN DATE, 
hiredateIn IN DATE, 
addressIn IN VARCHAR2,
cityIn IN VARCHAR2, 
stateIn IN VARCHAR2,
countryIn IN VARCHAR2,
postalIn IN VARCHAR2,
phoneIn IN VARCHAR2,
faxIn IN VARCHAR2,
emailIn IN VARCHAR2)
AS
    
BEGIN
   UPDATE EMPLOYEE SET lastName = lnameIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET firstName = fnameIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET title = titleIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET reportsto = reportstoIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET birthDate = birthdateIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET hireDate = hiredateIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET address = addressIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET city = cityIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET state = stateIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET country = countryIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET postalcode = postalIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET phone = phoneIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET fax = faxIn WHERE employeeId = idIn;
   UPDATE EMPLOYEE SET email = emailIn WHERE employeeId = idIn;
   COMMIT;
END;
/
