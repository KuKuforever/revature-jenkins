CREATE PROCEDURE getAlbumByName(aId IN NUMBER, albumName OUT VARCHAR2)
AS
    BEGIN
        SELECT Title INTO albumName FROM Album a WHERE a.AlbumId = aId;
    END;
/
