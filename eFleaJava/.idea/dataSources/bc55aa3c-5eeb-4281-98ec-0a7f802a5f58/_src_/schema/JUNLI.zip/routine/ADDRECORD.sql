CREATE PROCEDURE addRecord(
    iCustomerId IN NUMBER,
    iFirstName IN VARCHAR2,
    iLastName IN VARCHAR2,
    iCompany IN VARCHAR2,
    iAddress IN VARCHAR2,
    iCity IN VARCHAR2,
    iState IN VARCHAR2,
    iCountry IN VARCHAR2,
    iPostalCode IN VARCHAR2,
    iPhone IN VARCHAR2,
    iFax IN VARCHAR2,
    iEmail IN VARCHAR2,
    iSupportRepId IN NUMBER
)
AS
BEGIN
    INSERT INTO Customer (CustomerId, FirstName, LastName, Company, Address, 
    City, State, Country, PostalCode, Phone, Fax, Email, SupportRepId) 
    VALUES
    (iCustomerId, iFirstName, iLastName, iCompany, iAddress, 
    iCity, iState, iCountry, iPostalCode, iPhone, iFax, iEmail, iSupportRepId);
    COMMIT;
END;
/
