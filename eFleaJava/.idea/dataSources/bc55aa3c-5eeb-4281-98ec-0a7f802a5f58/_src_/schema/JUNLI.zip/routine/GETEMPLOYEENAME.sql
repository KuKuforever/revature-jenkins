CREATE PROCEDURE getEmployeeName
AS
    CURSOR name_cursor
    IS
    SELECT firstName, lastName FROM EMPLOYEE;
    eName name_cursor%ROWTYPE;
BEGIN
    OPEN name_cursor;
    LOOP
    FETCH name_cursor INTO eName;
    EXIT WHEN name_cursor%NOTFOUND;

    DBMS_OUTPUT.put_line(eName.firstName||' '||eName.lastName);
    END LOOP;
END;
/
