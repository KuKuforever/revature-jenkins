CREATE FUNCTION fnGetAlbumName(aId NUMBER)
RETURN VARCHAR2
IS aname VARCHAR2(256);
    BEGIN
    SELECT Title INTO aName FROM Album a WHERE a.AlbumId = aId;
    RETURN aName;
END;
/
