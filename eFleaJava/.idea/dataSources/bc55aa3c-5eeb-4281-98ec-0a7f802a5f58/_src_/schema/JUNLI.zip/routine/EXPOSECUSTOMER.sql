CREATE PROCEDURE exposeCustomer
(cId IN NUMBER, cName OUT VARCHAR2, cComp OUT VARCHAR2)
AS

BEGIN
    SELECT CONCAT(CONCAT(lastName,','),firstName) INTO cName FROM CUSTOMER WHERE customerId = cId;
    SELECT company INTO cComp FROM CUSTOMER WHERE customerId = cId;
END;
/
